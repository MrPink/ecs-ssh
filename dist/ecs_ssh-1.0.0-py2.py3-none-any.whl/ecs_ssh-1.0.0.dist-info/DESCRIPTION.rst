quickly and easily ssh to containers within ECS


